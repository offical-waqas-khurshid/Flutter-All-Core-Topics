package com.example.flutter_sqlite_habibi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
